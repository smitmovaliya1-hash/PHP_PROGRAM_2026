<?php

function studentDetails($name, $enrollmentNo, $semester)
{
    echo "Student Name : " . $name . "<br>";
    echo "Enrollment Number : " . $enrollmentNo . "<br>";
    echo "Semester : " . $semester . "<br>";
}

studentDetails("Krupal Bhimani", "92400527114", 5);

?>