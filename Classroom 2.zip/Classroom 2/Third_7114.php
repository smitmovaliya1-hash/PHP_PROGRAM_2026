<?php

function calculatePercentage($php, $os, $dbms, $python, $html)
{
    $total = $php + $os + $dbms + $python + $html;
    return ($total / 500) * 100;
}

$php = 80;
$os = 75;
$dbms = 90;
$python = 85;
$html = 70;

$total = $php + $os + $dbms + $python + $html;
$percentage = calculatePercentage($php, $os, $dbms, $python, $html);

?>

<!DOCTYPE html>
<html>
<head>
    <title>BCA Result</title>
</head>
<body>

<h2>BCA Semester 4 Result</h2>

<table border="1" cellpadding="10">
    <tr>
        <th>Subject</th>
        <th>Marks</th>
    </tr>

    <tr>
        <td>PHP Programming</td>
        <td><?php echo $php; ?></td>
    </tr>

    <tr>
        <td>Operating System</td>
        <td><?php echo $os; ?></td>
    </tr>

    <tr>
        <td>DBMS</td>
        <td><?php echo $dbms; ?></td>
    </tr>

    <tr>
        <td>Python Programming</td>
        <td><?php echo $python; ?></td>
    </tr>

    <tr>
        <td>HTML</td>
        <td><?php echo $html; ?></td>
    </tr>

    <tr>
        <th>Total Marks</th>
        <th><?php echo $total; ?></th>
    </tr>

    <tr>
        <th>Percentage</th>
        <th><?php echo $percentage . "%"; ?></th>
    </tr>
</table>

</body>
</html>