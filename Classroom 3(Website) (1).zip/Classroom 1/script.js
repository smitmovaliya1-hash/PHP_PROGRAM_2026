function showPopup(message){

    const popup =
    document.getElementById("popup");

    const popupMessage =
    document.getElementById("popupMessage");

    popupMessage.innerHTML = message;

    popup.style.display = "flex";
}



function closePopup(){

    document.getElementById(
    "popup"
    ).style.display = "none";

    window.location.href =
    "login.html";
}



function closeLoginPopup(){

    document.getElementById(
    "popup"
    ).style.display = "none";

}




const registerForm =
document.getElementById(
"registerForm"
);

if(registerForm){

registerForm.addEventListener(
"submit",

function(e){

e.preventDefault();

const username =
document.getElementById(
"regUsername"
).value;

const email =
document.getElementById(
"regEmail"
).value;

const password =
document.getElementById(
"regPassword"
).value;



let users =
JSON.parse(
localStorage.getItem("users")
) || [];



let exists =
users.find(

user =>

user.username === username

);



if(exists){

showPopup(
"Username Already Exists!"
);

return;

}



users.push({

username : username,
email : email,
password : password

});



localStorage.setItem(

"users",

JSON.stringify(users)

);



showPopup(

"Registration Successfully !!"

);

});

}




const loginForm =
document.getElementById(
"loginForm"
);

if(loginForm){

loginForm.addEventListener(
"submit",

function(e){

e.preventDefault();

const username =
document.getElementById(
"loginUsername"
).value;

const password =
document.getElementById(
"loginPassword"
).value;



let users =
JSON.parse(
localStorage.getItem(
"users"
)
) || [];



let validUser =
users.find(

user =>

user.username === username &&

user.password === password

);



if(validUser){

showPopup(

"Login Successfully !!<br><br>Welcome " +

username

);



setTimeout(function(){

window.location.href =
"student_form.html";

},4000);

}
else{

showPopup(

"Invalid Username Or Password"

);

}

});

}



const studentForm =
document.getElementById(
"studentForm"
);

if(studentForm){

studentForm.addEventListener(
"submit",

function(e){

e.preventDefault();




const firstName =
document.getElementById(
"firstName"
).value;

const lastName =
document.getElementById(
"lastName"
).value;

const studentContact =
document.getElementById(
"studentContact"
).value;

const fatherContact =
document.getElementById(
"fatherContact"
).value;

const address =
document.getElementById(
"address"
).value;



localStorage.setItem(
"firstName",
firstName
);

localStorage.setItem(
"lastName",
lastName
);

localStorage.setItem(
"studentContact",
studentContact
);

localStorage.setItem(
"fatherContact",
fatherContact
);

localStorage.setItem(
"address",
address
);




showPopup(

"Thank You For Filling This Form"

);




setTimeout(function(){

window.location.href =
"thankyou.html";

},4000);

});

}