<?php

$string = "welcome to php";

echo "<h2>strtoupper() Function</h2>";
echo "Original String: " . $string . "<br>";
echo "Uppercase String: " . strtoupper($string);

?>