<?php

$string = "WELCOME TO PHP";

echo "<h2>strtolower() Function</h2>";
echo "Original String: " . $string . "<br>";
echo "Lowercase String: " . strtolower($string);

?>