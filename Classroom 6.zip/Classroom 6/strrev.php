<?php

$string = "Programming";

echo "<h2>strrev() Function</h2>";
echo "Original String: " . $string . "<br>";
echo "Reverse String: " . strrev($string);

?>