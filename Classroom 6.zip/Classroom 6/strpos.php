<?php

$string = "Welcome to PHP Programming";

echo "<h2>strpos() Function</h2>";
echo "Original String: " . $string . "<br>";

$position = strpos($string, "PHP");

echo "Position of 'PHP': " . $position;

?>