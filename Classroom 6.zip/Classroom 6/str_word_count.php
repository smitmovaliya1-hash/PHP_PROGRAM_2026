<?php

$string = "PHP is easy to learn";

echo "<h2>str_word_count() Function</h2>";
echo "Original String: " . $string . "<br>";
echo "Total Words: " . str_word_count($string);

?>