<?php

$string = "Hello PHP";

echo "<h2>strlen() Function</h2>";
echo "Original String: " . $string . "<br>";
echo "Length of String: " . strlen($string);

?>